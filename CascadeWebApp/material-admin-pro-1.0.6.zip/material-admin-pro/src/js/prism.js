import Clipboard from 'clipboard';
import Prism from 'prismjs';
import 'prismjs/components/prism-pug';
import 'prismjs/plugins/toolbar/prism-toolbar';
import 'prismjs/plugins/copy-to-clipboard/prism-copy-to-clipboard';

window.addEventListener('DOMContentLoaded', event => {
    // Prism.js
    // https://prismjs.com/
});
