# Start Bootstrap License

You must purchase a license from Start Bootstrap in order to legally use this project.

You may purchase multiple licenses and each license is valid for only 1 domain.

For license information, visit <https://startbootstrap.com/licenses>.

View your purchased licenses here: <https://startbootstrap.com/account/invoices>

This file must remain in your project.

Please add your Order ID to this file here -> [ ]

**Copyright &copy; 2023 Start Bootstrap &trade; ALL RIGHTS RESERVED**
